updatePreviewLinks=function(){
var _1=window.location.toString();
getParameterByName=function(_2){
_2=_2.replace(/[\[]/,"\\[").replace(/[\]]/,"\\]");
var _3=new RegExp("[\\?&;]"+_2+"=([^&#;]*)"),_4=_3.exec(location.search);
return _4==null?"":decodeURIComponent(_4[1].replace(/\+/g," "));
};
var _5=_1.match("preview=Y")!=null;
var _6=_1.match("drafttok=")!=null;
if(!_5&&!_6){
return;
}
var _7=getParameterByName("drafttok");
$("a, iframe").each(function(_8){
var _9=window.location.host;
var _a=$(this).is("iframe")?"src":"href";
var _b=$(this).attr(_a);
if((_b.match("https?://"+_9)!=null||_b.charAt(0)=="/")&&_b.match("#")==null){
if(_b.match("^/download/i")!=null){
return;
}
if(_b.match("\\?")==null){
$(this).attr(_a,_b+"?preview=Y");
}else{
$(this).attr(_a,_b+";preview=Y");
}
_b=$(this).attr(_a);
if(_7){
if(_b.match("\\?")==null){
$(this).attr(_a,_b+"?drafttok="+_7);
}else{
$(this).attr(_a,_b+";drafttok="+_7);
}
}
}
});
var _c=document.cookie.indexOf("in_draft_mode")!=-1;
var _d=_5&&(_c||!_7);
if(_d){
editLoc=_1.replace(/\?.*/,"");
var _e=document.createElement("a");
_e.href=editLoc;
_e.className="editmode";
_e.appendChild(document.createTextNode("Return to edit mode"));
if($("#pageOffset").length){
$("#pageOffset").before(_e);
}else{
$(".pageOffset").before(_e);
}
}
};
$(document).ready(function(){
updatePreviewLinks();
});

